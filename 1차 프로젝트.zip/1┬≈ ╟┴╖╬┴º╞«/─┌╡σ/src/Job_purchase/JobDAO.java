package Job_purchase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JList;

public class JobDAO {

	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";

			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int insert(JobDTO dto) {
		connect();

		int cnt = 0;

		String sql = "insert into tb_purchase values(num.nextVal,?,?,?,sysdate)";

		try {

			pst = conn.prepareStatement(sql);
			pst.setString(1, dto.getPurchase_id());
			pst.setString(2, dto.getPurchase_title());
			pst.setString(3, dto.getPurchase_con());

			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

	public int update_title(JobDTO dto) {
		connect();
		int cnt = 0;

		try {
			String sql = "update tb_purchase set purchase_title=? , purchase_con=? where purchase_num=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, dto.getPurchase_title());
			pst.setString(2, dto.getPurchase_con());
			pst.setInt(3, dto.getPurchase_num());

			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return cnt;
	}
	public int delete(JobDTO dto) {
		connect();
		int cnt = 0;

		try {
			String sql = "delete from tb_purchase where purchase_num=?";
			pst = conn.prepareStatement(sql);

			pst.setInt(1, dto.getPurchase_num());

			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return cnt;
	}

	
	public ArrayList<JobDTO> all() {

		ArrayList<JobDTO> list = new ArrayList<JobDTO>();

		connect();

		try {
			String sql = "select * from tb_purchase";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while (rs.next()) {
				int purchase_num = rs.getInt(1);
				String purchase_id = rs.getString(2);
				String purchase_title = rs.getString(3);
				String purchase_con = rs.getString(4);
				String purchase_date = rs.getString(5);

				JobDTO dto = new JobDTO(purchase_num, purchase_id, purchase_title, purchase_con, purchase_date);
				list.add(dto);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close();
		}

		return list;
	}
	
	
}