create table tb_purchase(
   purchase_num number not null,
   purchase_id varchar2(50) not null,
   purchase_title varchar2(50) not null,
   purchase_con varchar2(50) not null,
   purchase_price varchar2(50) not null,
   purchase_date DATE not null
)

ALTER TABLE tb_purchase
ADD CONSTRAINT memberID2
FOREIGN KEY (purchase_id)
REFERENCES member (mem_id);

create sequence num start with 1 increment by 1;

drop table tb_purchase

select * from tb_purchase;

insert into tb_purchase values(num.nextVal,'ssdfvddvdf','sdfsfsf','sdfsdf','sdfsdf',sysdate)

	

