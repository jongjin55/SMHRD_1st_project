package Job_sale;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import Job_purchase.JobDAO;
import Job_purchase.JobDTO;
import Job_purchase.myGUI;
import ȸ������_�α���.LoginGUI;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class order_list2 {

	JFrame frame;
	private String header[] = {"��ȣ", "SAM", "��û �ð�"};
	private Object contents[][];
	private JTable table;
	private JScrollPane scrollPane_1;
	private JLabel lblNewLabel;
	private String purchaseid = LoginGUI.id;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public order_list2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		
		JobDAO dao = new JobDAO();
		ArrayList<JobDTO> list = dao.order();
		int a = 0;
		contents = new Object[list.size()][3];

		for (int i = 0; i < list.size(); i++) {
			if(!purchaseid.equals(list.get(i).getOrder_id())) {
				contents[a][0] = a + 1;
				contents[a][1] = list.get(i).getOrder_id();
				contents[a][2] = list.get(i).getOrder_date();
				a++;
			}
			
		}
		table = new JTable(contents, header) {
			// ����, �Է� �Ұ��ϰ� (�� ���� �Ұ��ϰ�)
			@Override
			public boolean isCellEditable(int row, int column) {

				return false;
			}
		};
		
		
		
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.window);
		frame.setBounds(100, 100, 578, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(65, 85, 433, 223);
		frame.getContentPane().add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("\uC2E0\uCCAD \uBAA9\uB85D");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 26, 562, 39);
		frame.getContentPane().add(lblNewLabel);
		frame.setLocationRelativeTo(null);
		
		btnNewButton = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				myGUI my = new myGUI();
				frame.dispose();
			}
		});
		btnNewButton.setBackground(new Color(176, 196, 222));
		btnNewButton.setBounds(401, 333, 97, 23);
		frame.getContentPane().add(btnNewButton);
		frame.setLocationRelativeTo(null);
		table.getParent().setBackground(Color.white);
		
		// ����Ŭ�� �̺�Ʈ
	      table.addMouseListener(new MouseAdapter() {

			@Override
	         public void mouseClicked(MouseEvent e) {
				
	             if(e.getClickCount()==2) {
	            
	                 int result = JOptionPane.showConfirmDialog(null, "�³��Ͻðڽ��ϱ�?", "���� ��û",JOptionPane.YES_NO_OPTION);
	            	 if(result==JOptionPane.YES_OPTION) {
	            		 myGUI mygui = new myGUI();
	            		 frame.dispose();
	            	 }
	         }}

	      });

	}

	public void setBoard(JobDTO jobDTO) {
		// TODO Auto-generated method stub
		
	}

	public void setBoard(Job_sale.JobDTO jobDTO) {
		// TODO Auto-generated method stub
		
	}
	
	

}
