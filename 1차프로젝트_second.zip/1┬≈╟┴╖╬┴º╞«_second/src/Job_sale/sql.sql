create table tb_sale(
   sale_num number not null,
   sale_id varchar(50) not null,
   sale_title varchar(50) not null,
   sale_con varchar2(50) not null,
   sale_price varchar(50) not null,
   sale_date DATE not null
)

drop table tb_sale
ALTER TABLE tb_sale
ADD CONSTRAINT memberID3
FOREIGN KEY (sale_id)
REFERENCES member (mem_id);

create table tbl_message(
	mid number not null,
	targetid varchar2(50) not null,
	sender varchar2(50) not null,
	message varchar2(50) not null,
	opendate date,
	senddate date default sysdate,
	primary key(mid));

create sequence num start with 1 increment by 1;
create sequence mesage_seq start with 1 increment by 1;

insert into tb_sale values(num.nextVal,'ȫ�쿵','sdfsd','sdfsdf', '12000',sysdate-3)
drop table tb_sale
drop table tbl_message

select * from tb_sale;
DELETE FROM tb_sale WHERE sale_date < TO_CHAR(sysdate - 1, 'yyyymmdd')

delete from tb_sale where sale_num=1;



