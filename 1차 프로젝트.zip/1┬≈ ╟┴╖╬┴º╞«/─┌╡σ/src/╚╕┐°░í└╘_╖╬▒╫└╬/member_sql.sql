create table member(

mem_name varchar2(20) not null,
mem_pn varchar2(20) not null unique,
mem_id varchar2(50) not null PRIMARY KEY,
mem_pw varchar2(50) not null,
mem_ph_num varchar2(30) not null,
mem_address varchar2(100) not null,
mem_email varchar2(50) not null
)


drop table member

select * from member

insert into member values('q','q','q','q','q','q','q')

create sequence studentSeq