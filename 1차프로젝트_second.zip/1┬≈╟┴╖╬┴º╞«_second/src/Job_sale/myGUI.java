package Job_sale;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;

import Job_purchase.order_list;
import ȸ������_�α���.InsertGradeGUI;
import ȸ������_�α���.LoginGUI;

public class myGUI {

	JFrame frame;
	private JTable table;

	private String header[] = { "��ȣ", "���̵�", "����", "����","���� ","�Խ� �ð�" };
	private Object contents[][];
	private int selectNum;
	static String purchase_id= LoginGUI.id;
	private JobDTO dto;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public myGUI() {
		initialize();
		frame.setVisible(true);
	}

	public void setBoard(JobDTO dto) {
		this.dto = dto;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		JobDAO dao = new JobDAO();
		ArrayList<JobDTO> list = dao.all();

		contents = new Object[list.size()][6];

		int find_num = 0;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getSale_id().equals(purchase_id)) {
				
				contents[find_num][0] = find_num + 1;
				contents[find_num][1] = list.get(i).getSale_id();
				contents[find_num][2] = list.get(i).getSale_title();
				contents[find_num][3] = list.get(i).getSale_con();
				contents[find_num][4] = list.get(i).getSale_price();
				contents[find_num][5] = list.get(i).getSale_date();
				find_num++;
			}
			}

		frame = new JFrame();
		frame.setBackground(SystemColor.controlLtHighlight);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 782, 497);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(60, 104, 654, 270);
		frame.getContentPane().add(scrollPane);

		table = new JTable(contents, header) {
			// ����, �Է� �Ұ��ϰ� (�� ���� �Ұ��ϰ�)
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		// Ŭ���� �� ��������
		table.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				JTable jt = (JTable) e.getSource();
				selectNum = jt.getSelectedRow();	
			}
		});

		scrollPane.setViewportView(table);

		JScrollPane scrollPane_1 = new JScrollPane();

		scrollPane.setColumnHeaderView(scrollPane_1);

		JButton insertBtn = new JButton("\uAE00 \uC791\uC131");
		insertBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insertGUI insert = new insertGUI();
				frame.dispose();
			}
		});

		JButton updateBtn = new JButton("\uAE00 \uC218\uC815");
		updateBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		updateBtn.setBackground(SystemColor.inactiveCaption);
		updateBtn.setBounds(346, 397, 97, 23);
		updateBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateGUI update = new updateGUI();
				update.setBoard(list.get(selectNum));
				update.frame.setVisible(true);
				frame.dispose();
			}
		});
		
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(updateBtn);
	
		
		JButton deleteBtn = new JButton("\uAE00 \uC0AD\uC81C");
		deleteBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		deleteBtn.setBackground(SystemColor.inactiveCaption);
		deleteBtn.setBounds(482, 397, 97, 23);
		deleteBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				setBoard(list.get(selectNum));
				
				int sale_num = dto.getSale_num(); 				
				
				JobDTO dto = new JobDTO(sale_num);
				JobDAO dao = new JobDAO();

				int cnt = dao.delete(dto);

				if (cnt == 0) {
					JOptionPane.showMessageDialog(null, "���� ����");

				} else {
					JOptionPane.showMessageDialog(null, "���� �Ϸ�.");
					myGUI my = new myGUI();
					frame.dispose(); // ���� â ����
				}

				myGUI insert = new myGUI();
				frame.dispose();
			}
		});
		
		frame.getContentPane().add(deleteBtn);

		JLabel lblNewLabel = new JLabel("\uB0B4 \uAE00 \uBAA9\uB85D");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 20));
		lblNewLabel.setBounds(200, 46, 366, 34);
		frame.getContentPane().add(lblNewLabel);

		JButton exitBtn = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		exitBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		exitBtn.setBackground(SystemColor.inactiveCaption);
		exitBtn.setBounds(618, 397, 97, 23);
		frame.getContentPane().add(exitBtn);
		frame.getContentPane().setLayout(null);
		
		JButton finishBtn = new JButton("\uC644\uB8CC \uBC0F \uD3C9\uC810\uC785\uB825");
		finishBtn.setBackground(new Color(176, 196, 222));
		finishBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		finishBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				

				setBoard(list.get(selectNum));
				
				int sale_num = dto.getSale_num(); 				
				
				JobDTO dto = new JobDTO(sale_num);
				JobDAO dao = new JobDAO();

				int cnt = dao.delete(dto);

				if (cnt == 0) {
					JOptionPane.showMessageDialog(null, "�Ϸ� ó�� ����");

				} else {
					JOptionPane.showMessageDialog(null, "�Ϸ�Ǿ����ϴ�.");
					InsertGradeGUI insertGUI = new InsertGradeGUI();
					frame.dispose(); // ���� â ����
				}
			}
		});
		finishBtn.setBounds(578, 56, 136, 23);
		frame.getContentPane().add(finishBtn);

		exitBtn.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				JobsaleGUI sale = new JobsaleGUI();
				scrollPane.setColumnHeaderView(scrollPane_1);
				frame.dispose();
			}
		});
		table.getParent().setBackground(Color.white);
		
		  table.addMouseListener(new MouseAdapter() {
		         @Override
		         public void mouseClicked(MouseEvent e) {
		             if(e.getClickCount()==2) {
		      
		            JTable jt = (JTable) e.getSource();
		            selectNum = jt.getSelectedRow();
		            order_list2 order2 = new order_list2();
		            order2.setBoard(list.get(selectNum));
		            order2.frame.setVisible(true);
		            
		            frame.dispose();

		         }}

		      });
	}
}
