package Job_sale;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import oracle.sql.DATE;

public class JobDAO {

	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";

			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int insert(JobDTO dto) {
		connect();

		int cnt = 0;

		String sql = "insert into tb_sale values(num.nextVal,?,?,?,?,sysdate)";

		try {

			pst = conn.prepareStatement(sql);
			pst.setString(1, dto.getSale_id());
			pst.setString(2, dto.getSale_title());
			pst.setString(3, dto.getSale_con());
			pst.setString(4, dto.getSale_price());
			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

	public int update_title(JobDTO dto) {
		connect();
		int cnt = 0;

		try {
			String sql = "update tb_sale set sale_title=?,sale_con=?,sale_price=? where sale_num=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, dto.getSale_title());
			pst.setString(2, dto.getSale_con());
			pst.setInt(4, dto.getSale_num());
			pst.setString(3, dto.getSale_price());
	
			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return cnt;
	}

	public int update_contents(JobDTO dto) {
		connect();
		int cnt = 0;
		try {
			String sql = "update tb_sale set sale_contents=? where sale_id=?";
			pst = conn.prepareStatement(sql);

			pst = conn.prepareStatement(sql);
			pst.setString(1, dto.getSale_id());
			pst.setString(2, dto.getSale_title());
			pst.setString(3, dto.getSale_con());
			pst.setString(3, dto.getSale_con());
			pst.setString(4, dto.getSale_price());

			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cnt;
	}

	public ArrayList<JobDTO> all() {

		ArrayList<JobDTO> list = new ArrayList<JobDTO>();

		connect();

		try {
			String sql = "select * from tb_sale";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while (rs.next()) {
				int sale_num = rs.getInt(1);
				String sale_id = rs.getString(2);
				String sale_title = rs.getString(3);
				String sale_con = rs.getString(4);
				String sale_price = rs.getString(5);
				String sale_date = rs.getString(6);
				

				JobDTO dto = new JobDTO(sale_num, sale_id, sale_title, sale_con, sale_price, sale_date);
				list.add(dto);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close();
		}

		return list;
	}

	public int delete(JobDTO dto) {
		connect();

		int cnt = 0;

		String sql = "delete from tb_sale where sale_num=?";

		try {

			pst = conn.prepareStatement(sql);
			pst.setInt(1, dto.getSale_num());

			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

	public int insertOrder(JobDTO dto) {
		connect();

	      int cnt = 0;
	      
	      String sql = "insert into purchase_order values(num.nextVal, ?, sysdate)";

	      try {

	         pst = conn.prepareStatement(sql);
	         
	         pst.setString(1, dto.getSale_id());
	      
	         cnt = pst.executeUpdate();

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      }
	      return cnt;
	   }
	public int dateDelete() {
	      connect();
	      int cnt = 0;

	      try {
	         String sql = "DELETE FROM tb_sale WHERE sale_date < TO_CHAR(sysdate - 1, 'yyyymmdd')";
	         
	         pst = conn.prepareStatement(sql);

	         cnt = pst.executeUpdate();

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            close();
	         } catch (Exception e) {
	            e.printStackTrace();
	         }

	      }
	      return cnt;

	   }

}