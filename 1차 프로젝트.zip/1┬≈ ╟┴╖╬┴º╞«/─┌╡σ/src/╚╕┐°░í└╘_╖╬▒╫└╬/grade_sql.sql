create table grade (

mem_id varchar2(50) not null,
mem_sum number(38,2) not null,
mem_n number(38,2) not null
)

ALTER TABLE grade
ADD CONSTRAINT memberID
FOREIGN KEY (mem_id)
REFERENCES member (mem_id);

insert into grade values('a',49, 11);
insert into grade values('q',50, 11);
insert into grade values('csw',40, 10);
insert into grade values('hhd',45, 10);
insert into grade values('pml',35, 10);
insert into grade values('kmh',40, 10);
insert into grade values('csm',15, 10);

drop table grade
delete from grade where mem_id='a';
select * from grade