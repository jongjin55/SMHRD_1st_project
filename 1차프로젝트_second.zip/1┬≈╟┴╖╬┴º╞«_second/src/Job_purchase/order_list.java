package Job_purchase;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import ȸ������_�α���.LoginGUI;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class order_list {

	JFrame frame;
	private String header[] = {"��ȣ", "SAM", "��û �ð�"};
	private Object contents[][];
	private JTable table;
	private JScrollPane scrollPane_1;
	private JLabel lblNewLabel;
	private String purchaseid = LoginGUI.id;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public order_list() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		JobDAO dao = new JobDAO();
		ArrayList<JobDTO> list = dao.order();

		contents = new Object[list.size()][3];
		int find_num = 0;
		for (int i = 0; i < list.size(); i++) {
			if(!purchaseid.equals(list.get(i).getOrder_id())) {
				contents[find_num][0] = find_num + 1;
				contents[find_num][1] = list.get(i).getOrder_id();
				contents[find_num][2] = list.get(i).getOrder_date();
				find_num++;
			}
			
		}
		table = new JTable(contents, header) {
			// ����, �Է� �Ұ��ϰ� (�� ���� �Ұ��ϰ�)
			@Override
			public boolean isCellEditable(int row, int column) {

				return false;
			}
		};
		
		
		
		
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 578, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(65, 85, 433, 223);
		frame.getContentPane().add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("\uC2E0\uCCAD \uBAA9\uB85D");
		lblNewLabel.setBounds(0, 26, 562, 39);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel);
		
		btnNewButton = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				myGUI my = new myGUI();
				frame.dispose();
			}
		});
		btnNewButton.setBackground(new Color(176, 196, 222));
		btnNewButton.setBounds(401, 333, 97, 23);
		frame.getContentPane().add(btnNewButton);
		frame.setLocationRelativeTo(null);
		table.getParent().setBackground(Color.white);
		
		// ����Ŭ�� �̺�Ʈ
	      table.addMouseListener(new MouseAdapter() {

			@Override
	         public void mouseClicked(MouseEvent e) {
				
	             if(e.getClickCount()==2) {
	            
	                 int result = JOptionPane.showConfirmDialog(null, "�³��Ͻðڽ��ϱ�?", "���� ��û",JOptionPane.YES_NO_OPTION);
	            	 if(result==JOptionPane.YES_OPTION) {
	            		 myGUI mygui = new myGUI();
	            		 frame.dispose();
	            	 }
	         }}

	      });

		
		
		
		
		
	}

	public void setBoard(JobDTO jobDTO) {
		// TODO Auto-generated method stub
		
	}
}
