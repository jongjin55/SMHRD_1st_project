package ȸ������_�α���;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JLabel;
import javax.swing.UIManager;

import Job_purchase.JobpurchaseGUI;

public class MainGUI {

	private JFrame frame;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			
			public void run() {
				try {
					MainGUI window = new MainGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 710, 540);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		
		JButton btn_join = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btn_join.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_join.setBackground(new Color(176, 196, 222));
		btn_join.setBounds(401, 394, 113, 49);
		btn_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JoinGUI_���� Join = new JoinGUI_����();
				frame.dispose();
			}
		});
		
		JButton btn_login = new JButton("\uB85C\uADF8\uC778");
		btn_login.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_login.setBackground(new Color(176, 196, 222));
		btn_login.setBounds(180, 394, 113, 49);
		btn_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LoginGUI login = new LoginGUI(); // ��ü ����
				frame.dispose(); // ���� â �Ⱥ��̱�
			}
		});
		
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btn_login);
		frame.getContentPane().add(btn_join);
		
		Container c = frame.getContentPane();
		ImageIcon img = new ImageIcon(MainGUI.class.getResource("/image/main.png"));
		JLabel imageLabel = new JLabel(img);
		imageLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		imageLabel.setBounds(-11, -11, 705, 512);
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(331, 539, 57, 15);
		c.add(imageLabel);
		frame.getContentPane().add(lblNewLabel);
	}
}
