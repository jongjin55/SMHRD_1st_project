package �޴�;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;

import ȸ������_�α���.GradeGUi;
import ȸ������_�α���.ReuGUI;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Container;
import javax.swing.SwingConstants;

import Job_purchase.JobpurchaseGUI;
import Job_sale.JobsaleGUI;
import chat.SimpleChatServer;


public class menu {

	private JFrame frame;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public menu() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 664, 681);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SAMS WORLD");
		lblNewLabel.setBounds(177, 31, 294, 52);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 25));
		frame.getContentPane().add(lblNewLabel);
		
		JButton btn_buy = new JButton("\uB3C4\uC640\uC918 SAMS!");
		btn_buy.setBounds(74, 111, 218, 108);
		btn_buy.setBackground(new Color(176, 196, 222));
		btn_buy.setFont(new Font("���� ����", Font.BOLD, 17));
		btn_buy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JobpurchaseGUI purchaseGUI = new JobpurchaseGUI();
				frame.dispose();
			}
		});
		frame.getContentPane().add(btn_buy);
		
		JButton btn_sell = new JButton("SAMS\uAC00 \uAC04\uB2E4!");
		btn_sell.setBounds(356, 111, 218, 108);
		btn_sell.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JobsaleGUI saleGUI = new JobsaleGUI();
				frame.dispose();
			}
		});
		btn_sell.setBackground(new Color(176, 196, 222));
		btn_sell.setFont(new Font("���� ����", Font.BOLD, 17));
		frame.getContentPane().add(btn_sell);
		
		JButton btn_search = new JButton("SAMS LIST");
		btn_search.setBounds(356, 280, 218, 108);
		btn_search.setBackground(new Color(176, 196, 222));
		btn_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GradeGUi G_GUI = new GradeGUi();
				frame.dispose();
			}
		});
		btn_search.setFont(new Font("���� ����", Font.BOLD, 17));
		frame.getContentPane().add(btn_search);
		
		JButton btn_update = new JButton("SAM \uC815\uBCF4\uC218\uC815");
		btn_update.setBounds(74, 448, 218, 108);
		btn_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ReuGUI reu = new ReuGUI();
				frame.dispose();
			}
		});
		btn_update.setFont(new Font("���� ����", Font.BOLD, 17));
		btn_update.setBackground(new Color(176, 196, 222));
		frame.getContentPane().add(btn_update);
		
		JButton btnSamsTalk = new JButton("SAMS TALK");
		btnSamsTalk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "�غ��� �Դϴ�.", "SAMS TALK", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnSamsTalk.setFont(new Font("���� ����", Font.BOLD, 17));
		btnSamsTalk.setBackground(new Color(176, 196, 222));
		btnSamsTalk.setBounds(74, 280, 218, 108);
		frame.getContentPane().add(btnSamsTalk);
		
		
		Container c = frame.getContentPane();
		ImageIcon img = new ImageIcon("C:/Users/SMHRD/Desktop/imgs/menu1.png"); 
		JLabel imageLabel = new JLabel(img);
		imageLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		imageLabel.setBounds(0, 0, 648, 623);
		c.add(imageLabel);
		
		
	}
}
