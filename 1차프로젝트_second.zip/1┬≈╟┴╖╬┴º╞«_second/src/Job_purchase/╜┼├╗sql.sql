create table purchase_order(
order_num number not null,
order_id varchar2(50) not null,
order_date DATE not null
)

ALTER TABLE purchase_order
ADD CONSTRAINT orderID10
FOREIGN KEY (order_id)
REFERENCES member (mem_id);


select * from purchase_order

drop table purchase_order

insert into purchase_order values(num.nextVal, 'qwe', sysdate)