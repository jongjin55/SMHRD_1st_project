package Job_sale;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JEditorPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class detailGUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	
		

	/**
	 * Create the application.
	 */


	
	public detailGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 517, 377);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("\uAE00 \uC81C\uBAA9");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel.setBounds(54, 67, 57, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JEditorPane ep_title = new JEditorPane();
		ep_title.setBackground(new Color(173, 216, 230));
		ep_title.setBounds(142, 67, 291, 23);
		frame.getContentPane().add(ep_title);
			
		JLabel lblNewLabel_1 = new JLabel("\uAE00 \uB0B4\uC6A9");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(54, 120, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JEditorPane ep_contents = new JEditorPane();
		ep_contents.setBackground(new Color(173, 216, 230));
		ep_contents.setBounds(142, 120, 291, 116);
		frame.getContentPane().add(ep_contents);
		
		JButton exitBtn = new JButton("\uB2EB\uAE30");
		exitBtn.setBackground(new Color(176, 196, 222));
		exitBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JobsaleGUI sale = new JobsaleGUI();
				frame.dispose();
			}
		});
		exitBtn.setBounds(336, 266, 97, 23);
		frame.getContentPane().add(exitBtn);
	}
}
