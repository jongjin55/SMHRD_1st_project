package ȸ������_�α���;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MemberDAO {

	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	// ojdbc ����̹��� �־������ �� �ٽ��غ�����
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";

			conn = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public int joinInsert(MemberVO vo) {

		connect();

		String sql = "insert into member values(?, ?, ?, ?, ?, ?, ?)";

		int cnt = 0;
		try {

			pst = conn.prepareStatement(sql);

			pst.setString(1, vo.getMem_name());
			pst.setString(2, vo.getMem_pn());
			pst.setString(3, vo.getMem_id());
			pst.setString(4, vo.getMem_pw());
			pst.setString(5, vo.getMem_ph_num());
			pst.setString(6, vo.getMem_address());
			pst.setString(7, vo.getMem_email());

			cnt = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			close();
		}

		return cnt;
	}

	public MemberVO loginSelect(String id, String pw) {

		MemberVO vo = null;

		connect();

		String sql = "select * from member where mem_id=? and mem_pw = ?";

		try {
			pst = conn.prepareStatement(sql);

			pst.setString(1, id);
			pst.setString(2, pw);

			rs = pst.executeQuery();

			while (rs.next()) {

				String getName = rs.getString(1);
				String getPn = rs.getString(2);
				String getId = rs.getString(3);
				String getPw = rs.getString(4);
				String getPhnum = rs.getString(5);
				String getAddress = rs.getString(6);
				String getEmail = rs.getString(7);

				vo = new MemberVO(getName, getPn, getId, getPw, getPhnum, getAddress, getEmail);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return vo;
	}

	public String selectOpen(MemberVO vo) {
		connect();

		String sql = "select mem_id from member where mem_id = ?";

		String mem_id = null;
		try {
			pst = conn.prepareStatement(sql);

			pst.setString(1, vo.getMem_id());

			rs = pst.executeQuery();

			while (rs.next()) {
				mem_id = rs.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return mem_id;
	}

	public MemberVO showOne(MemberVO vo) {
		connect();

	      String sql = "select * from member where mem_id = ?";
	      try {
	         pst = conn.prepareStatement(sql);

	         pst.setString(1, vo.getMem_id());

	         rs = pst.executeQuery();

	         while (rs.next()) {

	            String mem_name = rs.getString(1);
	            String mem_pn = rs.getString(2);
	            String mem_id = rs.getString(3);
	            String mem_pw = rs.getString(4);
	            String mem_ph_num = rs.getString(5);
	            String mem_address = rs.getString(6);
	            String mem_email = rs.getString(7);

	            vo = new MemberVO(mem_name, mem_pn, mem_id, mem_pw, mem_ph_num, mem_address, mem_email);

	         }

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      }
	      return vo;
	   }

	public int Update(MemberVO vo) {
		 connect();
	      
	      String sql = "update member set mem_pw = ?, mem_ph_num= ?, mem_address = ?, mem_email= ? where mem_id=?";
	      
	      int cnt = 0;
	      
	      try {
	         pst = conn.prepareStatement(sql);

	         pst.setString(1, vo.getMem_pw());
	         pst.setString(2, vo.getMem_ph_num());
	         pst.setString(3, vo.getMem_address());
	         pst.setString(4, vo.getMem_email());
	         pst.setString(5, vo.getMem_id());

	         cnt = pst.executeUpdate();
	         
	      } catch (Exception e) {
	         e.printStackTrace();
	      }finally {
	         close();
	      }
	      return cnt;

	}

	public int delete(MemberVO vo) {
		   
	      connect();
	      
	      String sql = "delete from member where mem_id = ?";
	      
	      int cnt = 0;
	      try {
	         pst = conn.prepareStatement(sql);

	         pst.setString(1, vo.getMem_id());

	         cnt = pst.executeUpdate();
	         
	      } catch (Exception e) {
	         e.printStackTrace();
	      }finally {
	         close();
	      }
	      return cnt;
	   }
}
