package Job_purchase;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import 메뉴.menu;

import java.awt.GridLayout;
import java.awt.Point;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.SwingConstants;

public class JobpurchaseGUI {

	JFrame frame;
	private JTable table;

	private String header[] = { "번호", "아이디", "제목", "내용", "게시 시간" };
	private Object contents[][];
	private int selectNum;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public JobpurchaseGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		

		JobDAO dao = new JobDAO();
		ArrayList<JobDTO> list = dao.all();

		contents = new Object[list.size()][5];

		for (int i = 0; i < list.size(); i++) {
			contents[i][0] = i + 1;
			contents[i][1] = list.get(i).getPurchase_id();
			contents[i][2] = list.get(i).getPurchase_title();
			contents[i][3] = list.get(i).getPurchase_con();
			contents[i][4] = list.get(i).getPurchase_date();
		}

		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 811, 530);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(100, 142, 619, 239);
		frame.getContentPane().add(scrollPane);

		table = new JTable(contents, header) {
			// 수정, 입력 불가하게 (셀 편집 불가하게)
			@Override
			public boolean isCellEditable(int row, int column) {

				return false;
			}
		};

		// 마우스 두번 클릭 이벤트
		// table.addMouseListener(new MouseAdapter() {
		// @Override
		// public void mouseClicked(MouseEvent e) {

		// int x = table.rowAtPoint(e.getPoint());
		// int y = table.columnAtPoint(e.getPoint());

		// if(x>=0 && y>=0) {
		// Job_sale.JTable table = (Job_sale.JTable) e.getSource();
		// if (e.getClickCount() == 1) {
		// 클릭시 상세정보 출력
		// JTable model2 = (JTable)e.getSource();
		// DefaultTableModel model = new DefaultTableModel();
		// DefaultTableModel model1 = (DefaultTableModel) model2.getModel();

		// Integer num = (Integer)model1.getValueAt(x, 0);
		// String id = (String)model1.getValueAt(x, 1);
		// String title = (String)model1.getValueAt(x, 2);
		// String contents = (String)model1.getValueAt(x, 3);
		// Integer time = (Integer)model1.getValueAt(x, 4);

		// String message = String.format("번호: %d, 아이디 : %s, 제목 : %s, 내용 : %s, 게시 시간 :
		// %d",num,id,title,contents,time );
		// JOptionPane.showMessageDialog(table, message, "더블 클릭", JOptionPane.OK_OPTION
		// );
		// }
		// }}
//      });

		scrollPane.setViewportView(table);

		JScrollPane scrollPane_1 = new JScrollPane();

		scrollPane.setColumnHeaderView(scrollPane_1);

		JButton insertBtn = new JButton("\uAE00 \uC791\uC131");
		insertBtn.setBackground(new Color(176, 196, 222));
		insertBtn.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		insertBtn.setIcon(new ImageIcon(JobpurchaseGUI.class.getResource("/image/write3.png")));
		insertBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insertGUI insert = new insertGUI();
				frame.dispose();
			}
		});

		insertBtn.setBounds(100, 95, 127, 23);
		frame.getContentPane().add(insertBtn);

		JButton exitBtn = new JButton("뒤로가기");
		exitBtn.setBackground(new Color(176, 196, 222));
		exitBtn.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu menu = new menu();
				frame.dispose();
			}
		});
		exitBtn.setBounds(622, 408, 97, 23);
		frame.getContentPane().add(exitBtn);

		JButton myBtn = new JButton("내 글 관리");
		myBtn.setBackground(new Color(176, 196, 222));
		myBtn.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		myBtn.setIcon(null);

		myBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//            myGUI insert = new myGUI();
				myGUI my = new myGUI();
				frame.dispose();
			}
		});
		myBtn.setBounds(627, 95, 92, 23);
		frame.getContentPane().add(myBtn);

		JLabel lblNewLabel = new JLabel("도와줘 SAMS!");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		lblNewLabel.setBounds(0, 20, 795, 37);
		frame.getContentPane().add(lblNewLabel);

		// 더블클릭 이벤트
	      table.addMouseListener(new MouseAdapter() {
	         @Override
	         public void mouseClicked(MouseEvent e) {
	             if(e.getClickCount()==2) {
	      
	            JTable jt = (JTable) e.getSource();
	            selectNum = jt.getSelectedRow();
	            showGUI show = new showGUI();
	            show.setBoard(list.get(selectNum));
	            show.frame.setVisible(true);
	            
	            frame.dispose();

	         }}

	      });

		// J테이블 설정
		table.getParent().setBackground(Color.white);

		scrollPane.setOpaque(false);
		scrollPane.getViewport().setOpaque(false);
		table.setRowMargin(0);
		table.getColumnModel().setColumnMargin(0);
		table.getTableHeader().setReorderingAllowed(false); // 이동 불가
		table.getTableHeader().setResizingAllowed(false);
		table.getParent().setBackground(Color.white);
	}

	private JLabel newJLabel(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	private ImageIcon newImageIcon(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setBoard(JobDTO jobDTO) {
		// TODO Auto-generated method stub
		
	}
}