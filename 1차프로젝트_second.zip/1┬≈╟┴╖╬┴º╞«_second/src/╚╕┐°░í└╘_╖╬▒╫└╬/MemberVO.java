package ȸ������_�α���;

public class MemberVO {

	private String mem_name;
	private String mem_pn;
	private String mem_id;
	private String mem_pw;
	private String mem_ph_num;
	private String mem_address;
	private String mem_email;

	public MemberVO(String mem_name, String mem_pn, String mem_id, String mem_pw,
			String mem_ph_num, String mem_address, String mem_email) {
		super();
		this.mem_name = mem_name;
		this.mem_pn = mem_pn;
		this.mem_id = mem_id;
		this.mem_pw = mem_pw;
		this.mem_ph_num = mem_ph_num;
		this.mem_address = mem_address;
		this.mem_email = mem_email;
	}

	public MemberVO(String id) {
		this.mem_id = id;
	}

	public String getMem_name() {
		return mem_name;
	}

	public String getMem_pn() {
		return mem_pn;
	}

	public String getMem_id() {
		return mem_id;
	}

	public String getMem_pw() {
		return mem_pw;
	}

	public String getMem_ph_num() {
		return mem_ph_num;
	}

	public String getMem_address() {
		return mem_address;
	}

	public String getMem_email() {
		return mem_email;
	}

}
