create table sale_order(
order_num number not null,
order_id varchar2(50) not null,
order_date DATE not null
)

ALTER TABLE sale_order
ADD CONSTRAINT orderID
FOREIGN KEY (order_id)
REFERENCES member (mem_id);


select * from SALE_ORDER

drop table sale_order