package Job_sale;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;

public class updateGUI {

	public JFrame frame;
	private JTextField tf_title;
	private JobDTO dto;
	private JTextPane tp_contents;
	private JTextField tf_price;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					updateGUI window = new updateGUI();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	public void setBoard(JobDTO dto) {
		this.dto = dto;
		tf_title.setText(dto.getSale_title());
		tp_contents.setText(dto.getSale_con());
		tf_price.setText(dto.getSale_price());
		

	}

	/**
	 * Create the application.
	 */
	public updateGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(SystemColor.controlLtHighlight);
		frame.getContentPane().setBackground(SystemColor.controlLtHighlight);
		frame.setBounds(100, 100, 444, 310);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		tp_contents = new JTextPane();
		tp_contents.setBackground(new Color(176, 196, 222));
		tp_contents.setBounds(99, 80, 288, 112);
		frame.getContentPane().add(tp_contents);

		JLabel lblNewLabel = new JLabel("\uB0B4\uC6A9");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel.setBounds(40, 80, 57, 15);
		frame.getContentPane().add(lblNewLabel);

		tf_title = new JTextField();
		tf_title.setBackground(new Color(176, 196, 222));
		tf_title.setBounds(97, 33, 290, 21);
		frame.getContentPane().add(tf_title);
		tf_title.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("\uC81C\uBAA9");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(40, 36, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);

		JButton finishBtn = new JButton("\uC218\uC815 \uC644\uB8CC");
		finishBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		finishBtn.setBackground(new Color(176, 196, 222));
		finishBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// dto.getSale_num()�Խñ� ������ȣ ��� ��ġ�ϴ� �����͸� ����
				
				String sale_title = tf_title.getText();
				String sale_con = tp_contents.getText();
				int sale_num = dto.getSale_num();
				String sale_price = tf_price.getText();
				
				JobDTO dto = new JobDTO(sale_title,sale_con,sale_num,sale_price);
				
				JobDAO dao = new JobDAO();
				
				int cnt = dao.update_title(dto);
				
				if (cnt == 0) {
					JOptionPane.showMessageDialog(null, "����� ������ ����� �Է����ּ���.");

				} else {
					JOptionPane.showMessageDialog(null, "���� �Ϸ�.");
					myGUI my = new myGUI();
					frame.dispose();  // ���� â ����
				}

				myGUI my = new myGUI();
				frame.dispose();
			}
		});

		
		finishBtn.setBounds(177, 238, 97, 23);
		frame.getContentPane().add(finishBtn);

		JButton cancelBtn = new JButton("\uCDE8\uC18C");
		cancelBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		cancelBtn.setBackground(new Color(176, 196, 222));
		cancelBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				myGUI insert = new myGUI();
				frame.dispose();
			}
		});
		cancelBtn.setBounds(290, 238, 97, 23);
		frame.getContentPane().add(cancelBtn);
		
		JLabel lblNewLabel_2 = new JLabel("\uAC00\uACA9");
		lblNewLabel_2.setBounds(26, 206, 57, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		tf_price = new JTextField();
		tf_price.setColumns(10);
		tf_price.setBackground(new Color(176, 196, 222));
		tf_price.setBounds(97, 202, 290, 21);
		frame.getContentPane().add(tf_price);
	}
}
