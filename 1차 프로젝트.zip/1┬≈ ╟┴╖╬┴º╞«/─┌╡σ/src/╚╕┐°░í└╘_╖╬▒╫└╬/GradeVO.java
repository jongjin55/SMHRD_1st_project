package ȸ������_�α���;



public class GradeVO {

	private String mem_id;
	private int mem_sum;
	private int mem_n;

	
	public GradeVO(String mem_id, int mem_sum, int mem_n) {
		this.mem_id = mem_id;
		this.mem_sum = mem_sum;
		this.mem_n = mem_n;
	}
	public GradeVO(String mem_id) {
		this.mem_id = mem_id;
		
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public int getMem_sum() {
		return mem_sum;
	}

	public void setMem_sum(int mem_sum) {
		this.mem_sum = mem_sum;
	}

	public int getMem_n() {
		return mem_n;
	}

	public void setMem_n(int mem_n) {
		this.mem_n = mem_n;
	}

}
