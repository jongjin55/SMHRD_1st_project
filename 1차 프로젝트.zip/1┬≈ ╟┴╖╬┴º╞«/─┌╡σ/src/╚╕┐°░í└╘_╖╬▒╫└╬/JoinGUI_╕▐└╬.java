package ȸ������_�α���;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.TextField;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.TextListener;
import java.awt.event.TextEvent;

public class JoinGUI_���� {

	private JFrame frame;
	private JTextField tf_name;
	private TextField tf_pn;
	private JTextField tf_id;
	private TextField tf_pw;
	private TextField tf_pwcheck;
	private JTextField tf_ph_num;
	private JTextField tf_email;
	private JTextField tf_address;
	private String id_check = "";
	private int check = 0;
	private int cnt = 0;
	private int cnt2 = 0;
	private TextField tf_pn2;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the application.
	 */
	public JoinGUI_����() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 569, 606);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(79, 101, 85, 30);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel_1.setBounds(224, 21, 106, 64);
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel_1);
		
		tf_name = new JTextField();
		tf_name.setBounds(181, 106, 191, 21);
		frame.getContentPane().add(tf_name);
		tf_name.setColumns(10);
		
		JLabel label = new JLabel("\uC8FC\uBBFC\uB4F1\uB85D\uBC88\uD638");
		label.setFont(new Font("���� ����", Font.BOLD, 12));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(79, 141, 85, 30);
		frame.getContentPane().add(label);
		
		tf_pn = new TextField(6);
		
		tf_pn.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
					cnt++;
					if (cnt == 6) {
						tf_pn2.requestFocus();
						cnt = 0;
				}
			}
		});
		tf_pn.setBounds(181, 147, 85, 21);
		tf_pn.setColumns(10);
		frame.getContentPane().add(tf_pn);
		
		JLabel label_1 = new JLabel("\uC544\uC774\uB514");
		label_1.setFont(new Font("���� ����", Font.BOLD, 12));
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(79, 181, 85, 30);
		frame.getContentPane().add(label_1);
		
		tf_id = new JTextField();
		tf_id.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		tf_id.setBounds(181, 186, 191, 21);
		tf_id.setColumns(10);
		frame.getContentPane().add(tf_id);
		
		JLabel label_2 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label_2.setFont(new Font("���� ����", Font.BOLD, 12));
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setBounds(79, 221, 85, 30);
		frame.getContentPane().add(label_2);
		
		tf_pw = new TextField();
		tf_pw.setEchoChar('*');
		tf_pw.setBounds(181, 226, 191, 21);
		tf_pw.setColumns(10);
		frame.getContentPane().add(tf_pw);
		
		JLabel label_3 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		label_3.setFont(new Font("���� ����", Font.BOLD, 12));
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setBounds(79, 261, 85, 30);
		frame.getContentPane().add(label_3);
		
		tf_pwcheck = new TextField();
		tf_pwcheck.setEchoChar('*');
		tf_pwcheck.setBounds(181, 266, 191, 21);
		tf_pwcheck.setColumns(10);
		frame.getContentPane().add(tf_pwcheck);
		
		JLabel label_4 = new JLabel("\uD734\uB300\uD3F0 \uBC88\uD638");
		label_4.setFont(new Font("���� ����", Font.BOLD, 12));
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setBounds(79, 301, 85, 30);
		frame.getContentPane().add(label_4);
		
		tf_ph_num = new JTextField();
		tf_ph_num.setBounds(181, 306, 191, 21);
		tf_ph_num.setColumns(10);
		frame.getContentPane().add(tf_ph_num);
		
		JLabel label_5 = new JLabel("\uC774\uBA54\uC77C");
		label_5.setFont(new Font("���� ����", Font.BOLD, 12));
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setBounds(79, 341, 85, 30);
		frame.getContentPane().add(label_5);
		
		tf_email = new JTextField();
		tf_email.setBounds(181, 346, 191, 21);
		tf_email.setColumns(10);
		frame.getContentPane().add(tf_email);
		
		JLabel label_6 = new JLabel("\uC8FC\uC18C");
		label_6.setFont(new Font("���� ����", Font.BOLD, 12));
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setBounds(79, 381, 85, 30);
		frame.getContentPane().add(label_6);
		
		tf_address = new JTextField();
		tf_address.setBounds(181, 386, 191, 21);
		tf_address.setColumns(10);
		frame.getContentPane().add(tf_address);
		
		JButton btn_join = new JButton("\uAC00\uC785");
		btn_join.setBackground(new Color(176, 196, 222));
		btn_join.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_join.setBounds(110, 459, 128, 51);
		btn_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mem_name = tf_name.getText();
				String mem_pn = tf_pn.getText()+tf_pn2.getText();	
				String mem_id = tf_id.getText();
				String mem_pw = tf_pw.getText();
				String mem_pwcheck = tf_pwcheck.getText();
				String mem_ph_num = tf_ph_num.getText();
				String mem_address = tf_address.getText();
				String mem_email = tf_email.getText();
				
				if(mem_pw.equals(mem_pwcheck)) {
					MemberVO vo = new MemberVO(mem_name, mem_pn, mem_id, mem_pw, mem_ph_num, mem_address, mem_email);
					MemberDAO dao = new MemberDAO();
					int cnt = dao.joinInsert(vo);

					if (cnt == 0) {
						JOptionPane.showMessageDialog(null, "ȸ������ ����", "ȸ������", JOptionPane.ERROR_MESSAGE);
					} else {
						if (check == 1) {
							JOptionPane.showMessageDialog(null, "ȸ������ ����"); // null ���� ����� �����ϰ� ���ִ� ����
							MainGUI.main(null); // �������� �̵�
							frame.dispose(); // â �ݱ�
						} else {
							JOptionPane.showMessageDialog(null, "���̵� �ߺ��˻縦 ���ּ���", "ȸ������", JOptionPane.ERROR_MESSAGE);
						}
					}
				} else {
					JOptionPane.showMessageDialog(null, "��й�ȣ ��ġ���� �ʽ��ϴ�.", "ȸ������", JOptionPane.ERROR_MESSAGE);
					tf_pw.setText("");  // ���� �ٲٰ� ���� �� set    ������ ���� ������  
					tf_pwcheck.setText(""); 
				}
			}
		});
		frame.getContentPane().add(btn_join);
		
		JButton btn_close = new JButton("\uB2EB\uAE30");
		btn_close.setBackground(new Color(176, 196, 222));
		btn_close.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_close.setBounds(315, 459, 128, 51);
		btn_close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainGUI.main(null); // �������� �̵�
				frame.dispose(); // â �ݱ�
			}
		});
		frame.getContentPane().add(btn_close);
		
		JButton btnNewButton = new JButton("\uC911\uBCF5 \uD655\uC778");
		btnNewButton.setBackground(new Color(176, 196, 222));
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id = tf_id.getText();

				MemberVO vo = new MemberVO(id);
				MemberDAO dao = new MemberDAO();
				id_check = dao.selectOpen(vo);

				if (id_check != null) {

					JOptionPane.showMessageDialog(null, "����ϰ� �ִ� ���̵��Դϴ�.", "���̵� �ߺ��˻�", JOptionPane.ERROR_MESSAGE);
					tf_id.setText(""); // ���� �ٲٰ� ���� �� set ������ ���� ������

				} else {
					check = 1;
					JOptionPane.showMessageDialog(null, "����� �� �ִ� ���̵��Դϴ�.");
				}
			}
		});
		btnNewButton.setBounds(404, 185, 97, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("-");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(266, 150, 21, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		tf_pn2 = new TextField(7);
		tf_pn2.setEchoChar('*');
		tf_pn2.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
					cnt2++;
					if (cnt2 == 7) {
						tf_id.requestFocus();
						cnt2 = 0;
				}
			}
		});
		
		tf_pn2.setColumns(10);
		tf_pn2.setBounds(287, 147, 85, 21);
		frame.getContentPane().add(tf_pn2);
		
	}
}
