package ȸ������_�α���;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;

import �޴�.menu;
import java.awt.Color;
import java.awt.Font;

public class GradeGUi {

	private JFrame frame;
	private JTextField tf_search;
	private Object[][] data;
	private JTable table;
	private String[] title = {"���̵�","�ŷ� Ƚ��","����"};
	private JButton btn_close;
	private String id = null;
	
	public String getId() {
		return tf_search.getText();
	}

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public GradeGUi() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		GradeDAO dao = new GradeDAO();
		ArrayList<GradeVO> list = dao.allGrade();
		data = new Object[list.size()][3];
		
		for(int i = 0; i < list.size(); i++) {
			data[i][0] = list.get(i).getMem_id();
			data[i][1] = list.get(i).getMem_n();
			float mean = (float) list.get(i).getMem_sum() / list.get(i).getMem_n();
			String mean2 = String.format("%.1f", mean);
			data[i][2] = mean2;
		}
		
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 458, 535);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		table = new JTable(data, title) {
	 
	    // ����, �Է� �Ұ��ϰ� (�� ���� �Ұ��ϰ�)
		public boolean isCellEditable(int row, int column) {
			return false;
			}
		};
	      
		JScrollPane scrollPane_1 = new JScrollPane(table);
		scrollPane_1.setBounds(34, 121, 374, 287);
		frame.getContentPane().add(scrollPane_1);
		
		
		tf_search = new JTextField();
		tf_search.setBounds(34, 67, 217, 21);
		frame.getContentPane().add(tf_search);
		tf_search.setColumns(10);
		
		JButton btn_search = new JButton("SAMS \uCC3E\uAE30");
		btn_search.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_search.setBackground(new Color(176, 196, 222));
		btn_search.setBounds(286, 65, 122, 23);
		btn_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String id = tf_search.getText();
				
				GradeDAO dao1 = new GradeDAO();
				GradeVO vo = dao1.selectOne(id);
				
				if(vo == null) {
					JOptionPane.showMessageDialog(null, "ã�� ���̵� �����ϴ�.");
				}else {
					JOptionPane.showMessageDialog(null,vo.getMem_id()+"���� ������ "+vo.getMem_sum() / vo.getMem_n()+"�Դϴ�. \n�ŷ� Ƚ�� : "+vo.getMem_n()+"ȸ");
				
				}	
			}
		});
		frame.getContentPane().add(btn_search);
		
		btn_close = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btn_close.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_close.setBackground(new Color(176, 196, 222));
		btn_close.setBounds(311, 440, 97, 23);
		btn_close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu menu = new menu();
				frame.dispose();
				//���ΰ� �����ؾ��� !!!!
							
			}
		});
		frame.getContentPane().add(btn_close);
		
		
		table.setRowMargin(0);
		table.getColumnModel().setColumnMargin(0);
		table.getTableHeader().setReorderingAllowed(false); // �̵� �Ұ�
		table.getTableHeader().setResizingAllowed(false); 
		table.getParent().setBackground(Color.white);

	

		DefaultTableCellRenderer tScheduleCellRenderer = new DefaultTableCellRenderer();
		tScheduleCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcmSchedule = table.getColumnModel();
		for (int i = 0; i < tcmSchedule.getColumnCount(); i++) {

			tcmSchedule.getColumn(i).setCellRenderer(tScheduleCellRenderer);

			}
	}
}
