package Job_purchase;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import ȸ������_�α���.LoginGUI;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

public class showGUI {

	public JFrame frame;
	private JTextField tf_title;
	private JobDTO dto;
	static String purchase_id = LoginGUI.id;
	static String purchase_title;
	static String purchase_con;
	static String purchase_price;
	public JLabel lbl_tf_title;
	public JLabel tf_price;
	public JLabel lbl_tp_contents;
	static String purchase_id2 = "qwe";
	static String purchase_id5;

	/**
	 * Launch the application. //
	 */
//   public static void main(String[] args) {
//      EventQueue.invokeLater(new Runnable() {
//         public void run() {
//            try {
//               showGUI window = new showGUI();
//               window.frame.setVisible(true);
//            } catch (Exception e) {
//               e.printStackTrace();
//            }
//         }
//      });
//   }

	/**
	 * Create the application.
	 */

	public void setBoard(JobDTO dto) {
		this.dto = dto;
		lbl_tf_title.setText(dto.getPurchase_title());
		lbl_tp_contents.setText(dto.getPurchase_con());
		tf_price.setText(dto.getPurchase_price());

	}

	public showGUI() {
		initialize();
		frame.setVisible(true);

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 511, 384);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		JLabel lblNewLabel = new JLabel("\uC81C\uBAA9");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel.setBounds(52, 51, 57, 15);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uB0B4\uC6A9");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(52, 126, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);



		lbl_tf_title = new JLabel();
		lbl_tf_title.setOpaque(true);
		lbl_tf_title.setBackground(new Color(176, 196, 222));
		lbl_tf_title.setForeground(SystemColor.desktop);
		lbl_tf_title.setBounds(121, 51, 308, 21);
		frame.getContentPane().add(lbl_tf_title);
		
		lbl_tp_contents = new JLabel();
		lbl_tp_contents.setVerticalAlignment(SwingConstants.TOP);
		lbl_tp_contents.setHorizontalAlignment(SwingConstants.LEFT);
		lbl_tp_contents.setOpaque(true);
		lbl_tp_contents.setBackground(new Color(176, 196, 222));
		lbl_tp_contents.setForeground(Color.BLACK);
		lbl_tp_contents.setBounds(122, 127, 307, 116);
		frame.getContentPane().add(lbl_tp_contents);
		
		JLabel tf_price = new JLabel();
		tf_price.setOpaque(true);
		tf_price.setForeground(Color.BLACK);
		tf_price.setBackground(new Color(176, 196, 222));
		tf_price.setBounds(121, 267, 308, 21);
		frame.getContentPane().add(tf_price);
		
		

		JButton applyBtn = new JButton("\uC2E0\uCCAD");
		applyBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		applyBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				
				int purchase_num = dto.getPurchase_num();
				String purchase_price = dto.getPurchase_price();

				JobDTO dto = new JobDTO(purchase_id, purchase_title, purchase_con, purchase_price);

				JobDAO dao = new JobDAO();

				int cnt = dao.insertOrder(dto);
				
				if (cnt == 0) {
					JOptionPane.showMessageDialog(null, "��û ����.");

				} else {
					if(purchase_id.equals(purchase_id5)){
						
						cnt = 0;
//					}else if(!purchase_id.equals(purchase_id2)){
					} else {
					
						JOptionPane.showMessageDialog(null, "��û �Ϸ�.");
						JobpurchaseGUI job = new JobpurchaseGUI();
						frame.dispose(); // ���� â ����
					}
					
				}

				
			}
		});

		applyBtn.setBounds(202, 298, 97, 23);
		frame.getContentPane().add(applyBtn);

		JButton cancelBtn = new JButton("\uCDE8\uC18C");
		cancelBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		cancelBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JobpurchaseGUI jobpurchase = new JobpurchaseGUI();
				frame.dispose();

			}
		});
		cancelBtn.setBounds(331, 298, 97, 23);
		frame.getContentPane().add(cancelBtn);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(40, 264, 57, 15);
		frame.getContentPane().add(lblNewLabel_2);
		

		JLabel lblNewLabel_3 = new JLabel("\uAC00\uACA9");
		lblNewLabel_3.setBounds(12, 264, 57, 15);
		frame.getContentPane().add(lblNewLabel_3);
		
		
		
	
	}
}