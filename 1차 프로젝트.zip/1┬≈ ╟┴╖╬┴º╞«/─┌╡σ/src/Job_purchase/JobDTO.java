package Job_purchase;

public class JobDTO {

	private int purchase_num;
	private String purchase_id;
	private String purchase_title;
	private String purchase_con;
	private String purchase_date;
	

	public JobDTO(String purchase_id, String purchase_title, String purchase_con) {
		super();
		this.purchase_id = purchase_id;
		this.purchase_title = purchase_title;
		this.purchase_con = purchase_con;
	}

	public JobDTO(String purchase_title, String purchase_con, int purchase_num) {
		super();
		this.purchase_title = purchase_title;
		this.purchase_con = purchase_con;
		this.purchase_num = purchase_num;
	}

	public JobDTO(int purchase_num) {
		super();

		this.purchase_num = purchase_num;
	}

	public JobDTO(int purchase_num, String purchase_id, String purchase_title, String purchase_con,
			String purchase_date) {
		this.purchase_num = purchase_num;
		this.purchase_id = purchase_id;
		this.purchase_title = purchase_title;
		this.purchase_con = purchase_con;
		this.purchase_date = purchase_date;
	}

	public int getPurchase_num() {
		return purchase_num;
	}

	public void setPurchase_num(int purchase_num) {
		this.purchase_num = purchase_num;
	}

	public String getPurchase_id() {
		return purchase_id;
	}

	public void setPurchase_id(String purchase_id) {
		this.purchase_id = purchase_id;
	}

	public String getPurchase_title() {
		return purchase_title;
	}

	public void setPurchase_title(String purchase_title) {
		this.purchase_title = purchase_title;
	}

	public String getPurchase_con() {
		return purchase_con;
	}

	public void Purchase(String purchase_con) {
		this.purchase_con = purchase_con;
	}

	public String getPurchase_date() {
		return purchase_date;
	}

	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}

}
