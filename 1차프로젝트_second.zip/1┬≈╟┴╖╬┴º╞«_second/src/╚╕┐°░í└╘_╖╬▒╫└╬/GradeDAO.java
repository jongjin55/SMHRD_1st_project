package ȸ������_�α���;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



public class GradeDAO {
	private GradeVO vo1 = null;
	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	// ojdbc ����̹��� �־������ �� �ٽ��غ�����
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String password = "hr";

			conn = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public ArrayList<GradeVO> allGrade() {
		ArrayList<GradeVO> list = new ArrayList<GradeVO>();

		connect();

		try {
			String sql = "select * from grade";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while (rs.next()) {

				String mem_id = rs.getString(1);
				int mem_sum = rs.getInt(2);
				int mem_n = rs.getInt(3);

				GradeVO vo = new GradeVO(mem_id, mem_sum, mem_n);
				list.add(vo);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close();
		}

		return list;
	}
	
	
	public GradeVO selectOne(String id) {
		// TODO Auto-generated method stub
		connect();
		
		try {
	
			String sql = "select * from grade where mem_id=?";
			// 3. sql ���� �غ� ��ü(preparedStatement) ����
			pst = conn.prepareStatement(sql);

			pst.setString(1, id);

			rs = pst.executeQuery();
			// db�� ���� �л� �Է��� ��� -> ���� �л��Դϴ� ���!!! �غ�����!!

			while (rs.next()) {

				String mem_id = rs.getString(1);
				int mem_sum = rs.getInt(2);
				int mem_n = rs.getInt(3);
				

				vo1 = new GradeVO(mem_id, mem_sum, mem_n);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return vo1;
	}
	
	public int searchInsert(GradeVO vo) {
		
		connect();
		
		String sql = "insert into memberinfo values(?)";
		int cnt = 0;
		try {
			
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, vo.getMem_id());
			
			cnt = pst.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally {
			close();
		}
	
		return cnt;
	}
	
	
	
}
