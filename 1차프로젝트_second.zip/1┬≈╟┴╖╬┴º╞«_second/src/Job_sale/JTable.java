package Job_sale;
import java.util.ArrayList;
	import java.util.Vector;

	import javax.swing.JFrame;
	import javax.swing.JScrollPane;

	public class JTable extends JFrame{
	   
}
