package Job_sale;

public class JobDTO {

	private int sale_num;
	private String sale_id;
	private String sale_title;
	private String sale_con;
	private String sale_price;
	private String sale_date;

	public JobDTO(String sale_id, String sale_title, String sale_con, String sale_price) {
		super();
		this.sale_id = sale_id;
		this.sale_title = sale_title;
		this.sale_con = sale_con;
		this.sale_price = sale_price;
	}
	
	public JobDTO(String sale_title, String sale_con, int sale_num,String sale_price) {
		super();
		this.sale_title = sale_title;
		this.sale_con =  sale_con;
		this.sale_num = sale_num;
		this.sale_price = sale_price;
		}

	public JobDTO(int sale_num, String sale_id, String sale_title, String sale_con, String sale_price, String sale_date) {
		this.sale_num = sale_num;
		this.sale_id = sale_id;
		this.sale_title = sale_title;
		this.sale_con = sale_con;
		this.sale_price = sale_price;
		this.sale_date = sale_date;
	}
	public JobDTO(int sale_num) {
		super();
		this.sale_num = sale_num;
	}
	

	public JobDTO(String sale_title, String sale_con) {
		this.sale_title = sale_title;
		this.sale_con = sale_con;
		
	}

	public int getSale_num() {
		return sale_num;
	}

	public void setSale_num(int sale_num) {
		this.sale_num = sale_num;
	}

	public String getSale_id() {
		return sale_id;
	}

	public void setSale_id(String sale_id) {
		this.sale_id = sale_id;
	}

	public String getSale_title() {
		return sale_title;
	}

	public void setSale_title(String sale_title) {
		this.sale_title = sale_title;
	}
	

	public String getSale_con() {
		return sale_con;
	}
	

	public void setSale_con(String sale_con) {
		this.sale_con = sale_con;
	}

	public String getSale_date() {
		return sale_date;
	}

	public void setSale_date(String sale_date) {
		this.sale_date = sale_date;
	}
	
	public String getSale_price() {

		return sale_price;
	}
	public void setSale_price(String sale_price) {
		this.sale_price = sale_price;
	}




}
