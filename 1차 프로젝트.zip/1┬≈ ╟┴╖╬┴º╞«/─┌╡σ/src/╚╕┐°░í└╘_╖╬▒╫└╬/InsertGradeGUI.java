package ȸ������_�α���;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import �޴�.menu;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;

public class InsertGradeGUI {
	String[] gradelist = {"������ ������ �ּ���.","5.0","4.5","4.0","3.5","3.0","2.5","2.0","1.5","1.0"};
	private JFrame frame;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InsertGradeGUI window = new InsertGradeGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public InsertGradeGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 515, 330);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		JLabel lblNewLabel = new JLabel("SAM \uC810\uC218\uC8FC\uAE30");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 20));
		lblNewLabel.setBounds(0, 27, 499, 84);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SAM���� �� ������ �������ּ���.");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(0, 108, 499, 34);
		frame.getContentPane().add(lblNewLabel_1);
		
		
		
		Container c = frame.getContentPane();
		JComboBox combo = new JComboBox(gradelist);
		
		combo.setBackground(new Color(255, 255, 255));
		combo.setFont(new Font("���� ����", Font.PLAIN, 12));
		combo.setBounds(88, 210, 189, 23);
		frame.getContentPane().add(combo);
		c.add(combo);
		
		JLabel lblNewLabel_2 = new JLabel("\uC785\uB825\uB41C \uC810\uC218\uB294 \uD3C9\uC810\uC5D0 \uBC18\uC601\uB429\uB2C8\uB2E4.");
		lblNewLabel_2.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(0, 144, 499, 23);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("�����ֱ�");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(combo.getSelectedItem().toString().equals(gradelist[0])) {
					JOptionPane.showMessageDialog(null, "�ٽ� ������ �ּ���", "SAM �����ֱ�", JOptionPane.ERROR_MESSAGE);
				}else {
					float num =  Float.parseFloat(combo.getSelectedItem().toString());
					System.out.println(num);
					//DB�� ����ֱ�
					menu menu = new menu();
					JOptionPane.showMessageDialog(null, "�����ֱ� ����!");
					frame.dispose(); 
					
				}
			}
		});
		btnNewButton.setBackground(new Color(176, 196, 222));
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 12));
		
		btnNewButton.setBounds(314, 210, 97, 23);
		frame.getContentPane().add(btnNewButton);
	}
}
