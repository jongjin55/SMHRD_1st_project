package ȸ������_�α���;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import �޴�.menu;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class LoginGUI {
	
	private JFrame frame;
	private JTextField tf_id;
	private JPasswordField tf_pw;
	public static String id;

	/**
	 * Launch the application.
	/**
	 * Create the application.
	 */
	public LoginGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 558, 417);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("SAM \uC774\uB984");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(110, 109, 120, 42);
		frame.getContentPane().add(lblNewLabel);
		
		tf_id = new JTextField();
		tf_id.setBounds(242, 120, 167, 21);
		frame.getContentPane().add(tf_id);
		tf_id.setColumns(10);
		
		JLabel label = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(110, 161, 120, 42);
		frame.getContentPane().add(label);
		
		tf_pw = new JPasswordField();
		tf_pw.setColumns(10);
		tf_pw.setBounds(242, 172, 167, 21);
		frame.getContentPane().add(tf_pw);
		
		JButton btn_login = new JButton("SAMS \uB9CC\uB098\uAE30");
		btn_login.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_login.setBackground(new Color(176, 196, 222));
		btn_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				id = tf_id.getText();
				String pw = tf_pw.getText();
				
				MemberDAO dao = new MemberDAO();
				MemberVO vo = dao.loginSelect(id, pw);
				
				if(vo == null) {
					JOptionPane.showMessageDialog(null, "�α��� ����", "�α���", JOptionPane.ERROR_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null, vo.getMem_name()+"�� ȯ���մϴ�.");
					menu menu =  new menu();
					frame.dispose();
				}
			}
		});
		btn_login.setBounds(128, 275, 120, 47);
		frame.getContentPane().add(btn_login);
		
		JButton btn_close = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btn_close.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_close.setBackground(new Color(176, 196, 222));
		btn_close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JoinGUI_���� Join = new JoinGUI_����();
				frame.dispose();
			}
		});
		btn_close.setBounds(296, 275, 120, 47);
		frame.getContentPane().add(btn_close);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome to SAMSWorld!");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(143, 29, 266, 53);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("SAM\uC774 \uC544\uB2C8\uC2DC\uBA74 \uD68C\uC6D0\uAC00\uC785 \uBC84\uD2BC\uC744 \uB20C\uB7EC\uC8FC\uC138\uC694.");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(143, 230, 266, 15);
		frame.getContentPane().add(lblNewLabel_2);
	}
}
