package Job_sale;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;

import ȸ������_�α���.LoginGUI;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class showGUI {

	protected static final String sale_price = null;
	public JFrame frame;
	private JTextField tf_title;
	private JTextPane tp_contents;
	static JobDTO dto;
	static String sale_id = LoginGUI.id;
	static String sale_title;
	static String sale_con;
	public JLabel lbl_tf_title;
	public JLabel lbl_tp_contents;
	public JLabel lbl_tf_price;
	static String sale_id2 = "qwe";
	private JTextField tf_price;

    

	/**
	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					showGUI window = new showGUI();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	

	public void setBoard(JobDTO dto) {
		this.dto = dto;
		lbl_tf_title.setText(dto.getSale_title());
		lbl_tp_contents.setText(dto.getSale_con());
		tf_price.setText(dto.getSale_price());
	}
	

	public showGUI() {
		initialize();
		frame.setVisible(true);
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 511, 384);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("\uC81C\uBAA9");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel.setBounds(52, 51, 57, 15);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uB0B4\uC6A9");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(52, 126, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		lbl_tf_title = new JLabel();
		lbl_tf_title.setOpaque(true);
		lbl_tf_title.setBackground(new Color(176, 196, 222));
		lbl_tf_title.setForeground(SystemColor.desktop);
		lbl_tf_title.setBounds(121, 51, 308, 21);
		frame.getContentPane().add(lbl_tf_title);
		
		tf_price = new JTextField();
		tf_price.setBackground(SystemColor.activeCaption);
		tf_price.setBounds(120, 269, 309, 21);
		frame.getContentPane().add(tf_price);
		tf_price.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\uAC00\uACA9");
		lblNewLabel_2.setBounds(52, 272, 57, 15);
		frame.getContentPane().add(lblNewLabel_2);
	
		lbl_tp_contents = new JLabel();
		lbl_tp_contents.setVerticalAlignment(SwingConstants.TOP);
		lbl_tp_contents.setHorizontalAlignment(SwingConstants.LEFT);
		lbl_tp_contents.setOpaque(true);
		lbl_tp_contents.setBackground(new Color(176, 196, 222));
		lbl_tp_contents.setForeground(Color.BLACK);
		lbl_tp_contents.setBounds(122, 127, 307, 116);
		frame.getContentPane().add(lbl_tp_contents);
		
		JButton applyBtn = new JButton("\uC2E0\uCCAD");
		applyBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		applyBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
//				sale_title = tf_title.getText();
//				sale_con = tp_contents.getText();
			
				JobDTO dto = new JobDTO(sale_id,sale_title,sale_con,sale_price);
				
				JobDAO dao = new JobDAO();
				
				int cnt = dao.insertOrder(dto);
				
				if (cnt == 0) {
					JOptionPane.showMessageDialog(null, "��û ����.");

				} else {
					if(sale_id.equals(sale_id2 )) {
						cnt = 0;
					}else {
						JOptionPane.showMessageDialog(null, "��û �Ϸ�.");
						JobsaleGUI job = new JobsaleGUI();
						frame.dispose();  // ���� â ����
					}
					
				}
			}
		});
		
	
	
		
		
		applyBtn.setBounds(205, 312, 97, 23);
		frame.getContentPane().add(applyBtn);
		
		JButton cancelBtn = new JButton("\uCDE8\uC18C");
		cancelBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		cancelBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JobsaleGUI jobsale = new JobsaleGUI();
				frame.dispose();
				
			}
		});
		cancelBtn.setBounds(332, 312, 97, 23);
		frame.getContentPane().add(cancelBtn);
		
	
		
	}
}
