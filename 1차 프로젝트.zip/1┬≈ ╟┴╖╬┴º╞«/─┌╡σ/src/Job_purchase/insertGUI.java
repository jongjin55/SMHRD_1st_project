package Job_purchase;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import ȸ������_�α���.LoginGUI;

public class insertGUI {

	private JFrame frame;
	private JTextField tf_title;
	private JTextField tp_contents;
	static String id;
	private String purchase_id = LoginGUI.id;     //�̸������ð�

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public insertGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 476, 343);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		tf_title = new JTextField();
		tf_title.setBackground(new Color(176, 196, 222));
		tf_title.setBounds(152, 42, 230, 21);
		frame.getContentPane().add(tf_title);
		tf_title.setColumns(10);

		JLabel lblNewLabel = new JLabel("\uAE00 \uC81C\uBAA9");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel.setBounds(61, 45, 57, 15);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uAE00 \uB0B4\uC6A9");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(61, 117, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JTextPane tp_contents = new JTextPane();
		tp_contents.setBackground(new Color(176, 196, 222));
		tp_contents.setBounds(150, 117, 232, 104);
		frame.getContentPane().add(tp_contents);

		JButton finishBtn = new JButton("\uC791\uC131\uC644\uB8CC");
		finishBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		finishBtn.setBackground(new Color(176, 196, 222));
		finishBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String purchase_title = tf_title.getText();
				String purchase_con = tp_contents.getText();

				JobDTO dto = new JobDTO(purchase_id, purchase_title, purchase_con);
				JobDAO dao = new JobDAO();

				int cnt = dao.insert(dto);
				
				if (cnt == 0) {

					JOptionPane.showMessageDialog(null, "����� ������ ����� �Է����ּ���.");

				} else {
					JOptionPane.showMessageDialog(null, "�ۼ� �Ϸ�.");
					JobpurchaseGUI purchaseGUI = new JobpurchaseGUI();
					frame.dispose(); // ���� â ����
				}
			}
		});
		finishBtn.setBounds(91, 249, 97, 23);
		frame.getContentPane().add(finishBtn);

		JButton exitBtn = new JButton("\uB2EB\uAE30");
		exitBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		exitBtn.setBackground(new Color(176, 196, 222));
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JobpurchaseGUI purchaseGUI = new JobpurchaseGUI();
				frame.dispose(); // ���� â ����
			}
		});
		exitBtn.setBounds(245, 249, 97, 23);
		frame.getContentPane().add(exitBtn);
	}
	

}
