package Job_purchase;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class showGUI {

	public JFrame frame;
	private JTextField tf_title;
	private JTextPane tp_contents;
	private JobDTO dto;
	static String purchase_id = "pbk";
	static String purchase_title;
	static String purchase_con;

	/**
	 * Launch the application. //
	 */
//   public static void main(String[] args) {
//      EventQueue.invokeLater(new Runnable() {
//         public void run() {
//            try {
//               showGUI window = new showGUI();
//               window.frame.setVisible(true);
//            } catch (Exception e) {
//               e.printStackTrace();
//            }
//         }
//      });
//   }

	/**
	 * Create the application.
	 */

	public void setBoard(JobDTO dto) {
		this.dto = dto;
		tf_title.setText(dto.getPurchase_title());
		tp_contents.setText(dto.getPurchase_con());

	}

	public showGUI() {
		initialize();
		frame.setVisible(true);

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 511, 384);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		JLabel lblNewLabel = new JLabel("\uC81C\uBAA9");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel.setBounds(52, 51, 57, 15);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uB0B4\uC6A9");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(52, 126, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);

		tf_title = new JTextField();
		tf_title.setBackground(new Color(176, 196, 222));
		tf_title.setForeground(new Color(176, 196, 222));
		tf_title.setBounds(121, 48, 308, 21);
		frame.getContentPane().add(tf_title);
		tf_title.setColumns(10);
		tf_title.setEnabled(false);

		tp_contents = new JTextPane();
		tp_contents.setBackground(new Color(176, 196, 222));
		tp_contents.setForeground(new Color(176, 196, 222));
		tp_contents.setBounds(121, 126, 308, 117);
		frame.getContentPane().add(tp_contents);
		tp_contents.setEnabled(false);

		JButton applyBtn = new JButton("\uC2E0\uCCAD");
		applyBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		applyBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// dto.getSale_num()�Խñ� ������ȣ ��� ��ġ�ϴ� �����͸� ����

				purchase_title = tf_title.getText();
				purchase_con = tp_contents.getText();
				
				// �Խñ� �ۼ��� ���̵� ����
				
				int purchase_num = dto.getPurchase_num();

				JobDTO dto = new JobDTO(purchase_title, purchase_con, purchase_num);

				JobDAO dao = new JobDAO();

				int cnt = dao.update_title(dto);

				if (cnt == 0) {
					JOptionPane.showMessageDialog(null, "��û ����.");

				} else {
					JOptionPane.showMessageDialog(null, "��û �Ϸ�.");
					
					JobpurchaseGUI job = new JobpurchaseGUI();
					frame.dispose(); // ���� â ����
				}

				
			}
		});

		applyBtn.setBounds(194, 278, 97, 23);
		frame.getContentPane().add(applyBtn);

		JButton cancelBtn = new JButton("\uCDE8\uC18C");
		cancelBtn.setFont(new Font("���� ����", Font.BOLD, 12));
		cancelBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JobpurchaseGUI jobpurchase = new JobpurchaseGUI();
				frame.dispose();

			}
		});
		cancelBtn.setBounds(332, 278, 97, 23);
		frame.getContentPane().add(cancelBtn);
	}
}