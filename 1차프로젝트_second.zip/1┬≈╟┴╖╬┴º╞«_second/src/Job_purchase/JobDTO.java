package Job_purchase;

public class JobDTO {

	private int purchase_num;
	private String purchase_id;
	private String purchase_title;
	private String purchase_con;
	private String purchase_date;
	private String purchase_price;
	
	private int order_num;
	private String order_id;
	
	
	public int getOrder_num() {
		return order_num;
	}

	public String getOrder_id() {
		return order_id;
	}

	public String getOrder_date() {
		return order_date;
	}
	

	private String order_date;
	

	public JobDTO(String purchase_id, String purchase_title, String purchase_con,String purchase_price) {
		super();
		this.purchase_id = purchase_id;
		this.purchase_title = purchase_title;
		this.purchase_con = purchase_con;
		this.purchase_price = purchase_price;
	}

	public JobDTO(String purchase_title, String purchase_con, int purchase_num,String purchase_price) {
		super();
		this.purchase_title = purchase_title;
		this.purchase_con = purchase_con;
		this.purchase_num = purchase_num;
		this.purchase_price = purchase_price;
	}
	
	public JobDTO(int purchase_num, String purchase_id, String purchase_title, String purchase_con, String purchase_price, String purchase_date) {
		this.purchase_num = purchase_num;
		this.purchase_id = purchase_id;
		this.purchase_title =purchase_title;
		this.purchase_con = purchase_con;
		this.purchase_price = purchase_price;
		this.purchase_date = purchase_date;
	}

	public JobDTO(int purchase_num) {
		super();

		this.purchase_num = purchase_num;
	}

	public JobDTO(int purchase_num, String purchase_id, String purchase_title, String purchase_con,
			String purchase_date) {
		this.purchase_num = purchase_num;
		this.purchase_id = purchase_id;
		this.purchase_title = purchase_title;
		this.purchase_con = purchase_con;
		this.purchase_date = purchase_date;
	}

	public JobDTO(int order_num, String order_id, String order_date) {
		this.order_num = order_num;
		this.order_id = order_id;
		this.order_date = order_date;
	}

	public int getPurchase_num() {
		return purchase_num;
	}

	public void setPurchase_num(int purchase_num) {
		this.purchase_num = purchase_num;
	}

	public String getPurchase_id() {
		return purchase_id;
	}

	public void setPurchase_id(String purchase_id) {
		this.purchase_id = purchase_id;
	}

	public String getPurchase_title() {
		return purchase_title;
	}

	public void setPurchase_title(String purchase_title) {
		this.purchase_title = purchase_title;
	}

	public String getPurchase_con() {
		return purchase_con;
	}

	public void Purchase(String purchase_con) {
		this.purchase_con = purchase_con;
	}

	public String getPurchase_date() {
		return purchase_date;
	}

	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}
	
	public String getPurchase_price() {
		return purchase_price;
	}

	public void setPurchase_price(String purchase_price) {
		this.purchase_price = purchase_price;
	}

	
	

}
