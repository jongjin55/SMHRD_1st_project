package ȸ������_�α���;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import �޴�.menu;

import java.awt.Font;
import java.awt.TextField;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ReuGUI {

	private JFrame frame;
	private JTextField tf_name;
	static String id;
	private JTextField tf_id;
	private TextField tf_pw;
	private TextField tf_pwcheck;
	private JTextField tf_ph_num;
	private JTextField tf_email;
	private JTextField tf_address;

//	private MemberDAO dao = null;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the application.
	 */
	public ReuGUI() {
		initialize();
		frame.setVisible(true);
	}

//	public void setBoard(String id) {
//		// TODO Auto-generated method stub
//		this.vo = dao.showOne(id);
//	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		MemberVO vo = new MemberVO(LoginGUI.id);
		MemberDAO dao = new MemberDAO();
		vo = dao.showOne(vo);

		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 568, 556);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("\uC774\uB984");
		lblNewLabel.setBounds(79, 101, 85, 30);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uAC1C\uC778\uC815\uBCF4 \uC218\uC815");
		lblNewLabel_1.setBounds(196, 20, 161, 64);
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel_1);

		tf_name = new JTextField(vo.getMem_name());
		tf_name.setBounds(182, 107, 191, 21);
		tf_name.setEditable(false);
		frame.getContentPane().add(tf_name);
		tf_name.setColumns(10);

		

		JLabel label_1 = new JLabel("\uC544\uC774\uB514");
		label_1.setBounds(79, 141, 85, 30);
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().add(label_1);

		tf_id = new JTextField(vo.getMem_id());
		tf_id.setBounds(182, 147, 191, 21);
		tf_id.setEditable(false);
		tf_id.setColumns(10);
		frame.getContentPane().add(tf_id);

		JLabel label_2 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label_2.setBounds(79, 181, 85, 30);
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().add(label_2);

		tf_pw = new TextField(vo.getMem_pw());
		tf_pw.setBounds(182, 187, 191, 21);
		tf_pw.setEchoChar('*');
		tf_pw.setColumns(10);
		frame.getContentPane().add(tf_pw);

		JLabel label_3 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		label_3.setBounds(79, 220, 85, 30);
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().add(label_3);

		tf_pwcheck = new TextField(vo.getMem_pw());
		tf_pwcheck.setBounds(182, 226, 191, 21);
		tf_pwcheck.setEchoChar('*');
		tf_pwcheck.setColumns(10);
		frame.getContentPane().add(tf_pwcheck);

		JLabel label_4 = new JLabel("\uD734\uB300\uD3F0 \uBC88\uD638");
		label_4.setBounds(79, 260, 85, 30);
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().add(label_4);

		tf_ph_num = new JTextField(vo.getMem_ph_num());
		tf_ph_num.setBounds(182, 266, 191, 21);
		tf_ph_num.setColumns(10);
		frame.getContentPane().add(tf_ph_num);

		JLabel label_5 = new JLabel("\uC774\uBA54\uC77C");
		label_5.setBounds(79, 300, 85, 30);
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().add(label_5);

		tf_email = new JTextField(vo.getMem_email());
		tf_email.setBounds(182, 306, 191, 21);
		tf_email.setColumns(10);
		frame.getContentPane().add(tf_email);

		JLabel label_6 = new JLabel("\uC8FC\uC18C");
		label_6.setBounds(79, 340, 85, 30);
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setFont(new Font("���� ����", Font.BOLD, 12));
		frame.getContentPane().add(label_6);

		tf_address = new JTextField(vo.getMem_address());
		tf_address.setBounds(182, 346, 191, 21);
		tf_address.setColumns(10);
		frame.getContentPane().add(tf_address);

		JButton btn_reuse = new JButton("\uC218\uC815\uC644\uB8CC");
		btn_reuse.setBounds(79, 417, 128, 51);
		btn_reuse.setFont(new Font("���� ����", Font.PLAIN, 12));
		btn_reuse.setBackground(new Color(176, 196, 222));
		btn_reuse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mem_id = tf_id.getText();
				String mem_pw = tf_pw.getText();
				String mem_pwcheck = tf_pwcheck.getText();
				String mem_ph_num = tf_ph_num.getText();
				String mem_address = tf_address.getText();
				String mem_email = tf_email.getText();

				if (mem_pw.equals(mem_pwcheck)) {
					MemberVO vo = new MemberVO("", "", mem_id, mem_pw, mem_ph_num, mem_address, mem_email);
					MemberDAO dao = new MemberDAO();
					int cnt = dao.Update(vo);

					if (cnt != 0) {
						JOptionPane.showMessageDialog(null, "�������� ���� �Ϸ�");
						menu me = new menu();
						frame.dispose();
					} else {
						JOptionPane.showMessageDialog(null, "��ĭ�� ä���ּ���!", "������������", JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, "��й�ȣ ��ġ���� �ʽ��ϴ�.", "������������", JOptionPane.ERROR_MESSAGE);
					tf_pw.setText(""); // ���� �ٲٰ� ���� �� set ������ ���� ������
					tf_pwcheck.setText("");
				}
			}
		});
		frame.getContentPane().add(btn_reuse);

		JButton btn_close = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btn_close.setBounds(345, 417, 128, 51);
		btn_close.setBackground(new Color(176, 196, 222));
		btn_close.setFont(new Font("���� ����", Font.BOLD, 12));
		btn_close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu menu = new menu(); // �������� �̵�
				frame.dispose(); // â �ݱ�
			}
		});
		frame.getContentPane().add(btn_close);

		JButton btn_delete = new JButton("\uD68C\uC6D0\uD0C8\uD1F4");
		btn_delete.setBackground(new Color(176, 196, 222));
		btn_delete.setBounds(230, 425, 92, 37);
		btn_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int result = JOptionPane.showConfirmDialog(null, "���� Ż���Ͻðڽ��ϱ�?", "ȸ��Ż��",
						JOptionPane.YES_NO_OPTION);
				  if (result == JOptionPane.YES_OPTION) {
		               MemberVO vo = new MemberVO(LoginGUI.id);
		               MemberDAO dao = new MemberDAO();
		               int cnt = dao.delete(vo);

		               if(cnt != 0) {
		               JOptionPane.showMessageDialog(null, "ȸ�� Ż��Ǿ����ϴ�.", "ȸ��Ż��", JOptionPane.INFORMATION_MESSAGE);
		               LoginGUI login = new LoginGUI();
		               frame.dispose();
		               }else {
		                  JOptionPane.showMessageDialog(null, "ȸ��Ż�� ����!", "ȸ��Ż��", JOptionPane.ERROR_MESSAGE);
		               }
		            }
			}

		});
		frame.getContentPane().add(btn_delete);
	}

}
